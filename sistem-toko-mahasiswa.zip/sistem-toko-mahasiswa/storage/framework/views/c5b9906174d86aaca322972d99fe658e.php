<footer>
    <p>Laravel UTS Project</p>
</footer><?php /**PATH D:\FrameWork\sistem-toko-mahasiswa\sistem-toko-mahasiswa\resources\views/layouts/footer.blade.php ENDPATH**/ ?>