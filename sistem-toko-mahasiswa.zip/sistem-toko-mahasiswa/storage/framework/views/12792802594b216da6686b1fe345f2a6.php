<html>
<head></head>
<body>
    <?php echo $__env->yieldContent('judul-menu'); ?>
    <?php echo $__env->yieldContent('isi-menu'); ?>
</body>
</html><?php /**PATH D:\FrameWork\sistem-toko-mahasiswa\sistem-toko-mahasiswa\resources\views/utama.blade.php ENDPATH**/ ?>