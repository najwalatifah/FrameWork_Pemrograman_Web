

<?php $__env->startSection('title', 'UTS Database'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Menu UTS Database</h1>
    <p>Ini adalah halaman untuk UTS Database.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FrameWork\sistem-toko-mahasiswa\sistem-toko-mahasiswa\resources\views/uts_database.blade.php ENDPATH**/ ?>