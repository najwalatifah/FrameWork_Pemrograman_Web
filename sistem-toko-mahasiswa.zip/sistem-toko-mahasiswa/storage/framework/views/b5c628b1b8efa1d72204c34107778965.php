<div class="alert alert-<?php echo e($type); ?>">
    <!-- Happiness is not something readymade. It comes from your own actions. - Dalai Lama -->
</div><?php /**PATH D:\FrameWork\sistem-toko-mahasiswa\sistem-toko-mahasiswa\resources\views/components/alert.blade.php ENDPATH**/ ?>