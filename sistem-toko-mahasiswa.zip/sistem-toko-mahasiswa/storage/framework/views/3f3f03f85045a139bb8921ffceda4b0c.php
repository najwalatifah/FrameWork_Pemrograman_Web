

<?php $__env->startSection('title', 'Halaman produk'); ?>

<?php $__env->startSection('content'); ?>

    <h1>ini adalah halaman produk</h1>
    <h1>selamat datang <?php echo e($nama); ?></h1>

    <div class="alert alert-<?php echo e($alertType); ?>">
        <?php echo e($alertMessage); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FrameWork\sistem-toko-mahasiswa\sistem-toko-mahasiswa\resources\views/produk.blade.php ENDPATH**/ ?>