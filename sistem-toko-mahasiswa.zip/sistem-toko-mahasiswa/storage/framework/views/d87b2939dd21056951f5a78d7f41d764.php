<!DOCTYPE html>
<html>
<head>
    <title>Data Angka</title>
</head>
<body>
    <h1>Hasil Angka: <?php echo e($result); ?></h1>
</body>
</html><?php /**PATH D:\FrameWork\sistem-toko-mahasiswa\sistem-toko-mahasiswa\resources\views/product.blade.php ENDPATH**/ ?>