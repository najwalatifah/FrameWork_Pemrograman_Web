<h2>Edit Produk</h2>
<form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <label>Nama:</label><br>
    <input type="text" name="name" value="<?php echo e($product->name); ?>"><br>
    <label>Harga:</label><br>
    <input type="number" name="price" value="<?php echo e($product->price); ?>"><br>
    <label>Stok:</label><br>
    <input type="number" name="stock" value="<?php echo e($product->stock); ?>"><br><br>
    <button type="submit">Update</button>
</form><?php /**PATH D:\FrameWork\sistem-toko-mahasiswa\resources\views/produk/edit.blade.php ENDPATH**/ ?>