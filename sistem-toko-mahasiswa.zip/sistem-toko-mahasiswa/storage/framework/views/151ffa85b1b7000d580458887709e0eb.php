

<?php $__env->startSection('title', 'Halaman UTS'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Halaman UTS</h1>
    <p>Ini adalah body halaman UTS </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FrameWork\sistem-toko-mahasiswa\sistem-toko-mahasiswa\resources\views/uts.blade.php ENDPATH**/ ?>