

<?php $__env->startSection('judul-menu'); ?>

<p>ini adalah tampilan dari judul menu user dengan id: <?php echo e($isi_data); ?></p>

<?php if($isi_data>20): ?>
    <p>isi data lebih dari 20</p>
<?php elseif($isi_data>15): ?>
    <p>isi data lebih dari 25</p>
<?php else: ?>
    <p>isi data kurang dari 15</p>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('isi-menu'); ?>

<p>ini adalah tampilan dari isi menu</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('utama', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FrameWork\sistem-toko-mahasiswa\sistem-toko-mahasiswa\resources\views/barang.blade.php ENDPATH**/ ?>