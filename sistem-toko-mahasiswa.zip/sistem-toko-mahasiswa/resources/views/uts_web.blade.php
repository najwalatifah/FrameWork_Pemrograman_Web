@extends('layouts.app')

@section('title', 'UTS Pemrograman Web')

@section('content')
    <h1>Menu UTS Pemrograman Web</h1>
    <p>Ini adalah halaman untuk UTS Pemrograman Web.</p>
@endsection
