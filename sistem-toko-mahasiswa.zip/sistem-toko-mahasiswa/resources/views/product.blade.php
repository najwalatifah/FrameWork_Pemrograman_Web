<!DOCTYPE html>
<html>
<head>
    <title>Data Angka</title>
</head>
<body>
    <h1>Hasil Angka: {{ $result }}</h1>
</body>
</html>