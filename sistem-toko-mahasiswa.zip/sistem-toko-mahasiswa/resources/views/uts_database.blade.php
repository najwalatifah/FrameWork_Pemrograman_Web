@extends('layouts.app')

@section('title', 'UTS Database')

@section('unsika')
    <h1>Menu UTS Database</h1>
    <p>Ini adalah halaman untuk UTS Database.</p>
@endsection
