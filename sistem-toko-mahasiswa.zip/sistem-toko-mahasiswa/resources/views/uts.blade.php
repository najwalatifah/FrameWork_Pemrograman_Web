@extends('layouts.app')

@section('title', 'Halaman UTS')

@section('content')
    <h1>Halaman UTS</h1>
    <p>Ini adalah body halaman UTS </p>
@endsection
