<html>
<head></head>
<body>
    @yield('judul-menu')
    @yield('isi-menu')
</body>
</html>